package changYong;

public class MainApp {
	public static void main(String[] args) {
		int[] list = {1,2,3};
		Solution solution = new Solution(list);
		System.out.println(list[0]);
		System.out.println(solution.shuffle()[0]);
		hanSu test = new hanSu();
		test.biao();
		test.jiaFa();
		System.out.println("");
		System.out.println(test.a);		
	}
}
